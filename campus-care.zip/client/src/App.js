
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Goals from './pages/Goals';
import DietPlanner from './pages/DietPlanner';

function App() {
  const isAuthenticated = localStorage.getItem('token');

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="/goals" element={isAuthenticated ? <Goals /> : <Navigate to="/login" />} />
        <Route path="/diet" element={isAuthenticated ? <DietPlanner /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
        